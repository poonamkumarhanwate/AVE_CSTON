
import os
import cv2
import torch
from torch.utils.data import Dataset

class VideoDataset(Dataset):
    def __init__(self, folder, sequence_length=8):
        self.folder = folder
        self.sequence_length = sequence_length
        self.frames = sorted(os.listdir(folder))

    def __len__(self):
        return len(self.frames) - self.sequence_length

    def __getitem__(self, idx):
        seq = []
        for i in range(self.sequence_length):
            path = os.path.join(self.folder, self.frames[idx+i])
            img = cv2.imread(path)
            img = cv2.resize(img,(128,128))
            img = img/255.0
            img = torch.tensor(img).permute(2,0,1).float()
            seq.append(img)
        seq = torch.stack(seq)
        return seq
