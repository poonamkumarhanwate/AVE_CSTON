
import torch
import torch.nn as nn

class SpatioTemporalEncoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv3d = nn.Sequential(
            nn.Conv3d(3,32,3,padding=1),
            nn.ReLU(),
            nn.MaxPool3d(2),

            nn.Conv3d(32,64,3,padding=1),
            nn.ReLU(),
            nn.MaxPool3d(2),

            nn.Conv3d(64,128,3,padding=1),
            nn.ReLU()
        )

    def forward(self,x):
        return self.conv3d(x)

class AttentionBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.attn = nn.Sequential(
            nn.Conv3d(channels,channels,1),
            nn.Sigmoid()
        )

    def forward(self,x):
        w = self.attn(x)
        return x * w

class AVE_CSTON(nn.Module):
    def __init__(self):
        super().__init__()

        self.encoder = SpatioTemporalEncoder()

        self.attn = AttentionBlock(128)

        self.decoder = nn.Sequential(
            nn.ConvTranspose3d(128,64,3,padding=1),
            nn.ReLU(),
            nn.ConvTranspose3d(64,32,3,padding=1),
            nn.ReLU(),
            nn.ConvTranspose3d(32,3,3,padding=1),
            nn.Sigmoid()
        )

    def forward(self,x):
        z = self.encoder(x)
        z = self.attn(z)
        recon = self.decoder(z)
        return recon
