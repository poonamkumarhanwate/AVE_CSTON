
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix

def plot_loss(loss_history):

    plt.figure()
    plt.plot(loss_history)
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("Training Loss Curve")
    plt.show()

def plot_pr(recall, precision):

    plt.figure()
    plt.plot(recall,precision)
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision Recall Curve")
    plt.show()

def plot_confusion(labels,preds):

    cm = confusion_matrix(labels,preds)

    plt.figure()
    plt.imshow(cm)
    plt.title("Confusion Matrix")
    plt.show()
