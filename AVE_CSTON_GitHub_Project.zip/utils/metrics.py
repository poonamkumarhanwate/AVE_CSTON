
from sklearn.metrics import roc_auc_score, precision_recall_curve

def compute_auc(labels, scores):
    return roc_auc_score(labels, scores)

def compute_pr(labels, scores):
    precision, recall, _ = precision_recall_curve(labels, scores)
    return precision, recall
