
from training.train import train
from visualization.graphs import plot_loss

if __name__ == "__main__":

    data_folder = "datasets/UCSD/train_frames"

    model, loss_history = train(data_folder)

    plot_loss(loss_history)
