
import torch
from torch.utils.data import DataLoader
from datasets.dataset_loader import VideoDataset
from models.ave_cston_model import AVE_CSTON
from utils.loss import reconstruction_loss

def train(data_folder):

    dataset = VideoDataset(data_folder)
    loader = DataLoader(dataset,batch_size=4,shuffle=True)

    model = AVE_CSTON()
    optimizer = torch.optim.Adam(model.parameters(),lr=0.0001)

    loss_history = []

    for epoch in range(10):

        total_loss = 0

        for seq in loader:

            seq = seq.permute(0,2,1,3,4)

            recon = model(seq)

            loss = reconstruction_loss(seq,recon)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        loss_history.append(total_loss)

        print("Epoch:",epoch,"Loss:",total_loss)

    return model, loss_history
