
import torch
from torch.utils.data import DataLoader
from datasets.dataset_loader import VideoDataset
from models.ave_cston_model import AVE_CSTON

def test(data_folder):

    dataset = VideoDataset(data_folder)
    loader = DataLoader(dataset,batch_size=1)

    model = AVE_CSTON()
    model.eval()

    scores = []

    with torch.no_grad():
        for seq in loader:

            seq = seq.permute(0,2,1,3,4)

            recon = model(seq)

            error = torch.mean((recon-seq)**2).item()

            scores.append(error)

    return scores
